#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <string>
#include <cstdlib>

using namespace std;

struct Instrument {
    string name;
    int weight;
    int value;
};

// Function to display instruments
void display(const vector<Instrument>& items) {
    cout << "\n=================================================\n";
    cout << "               INSTRUMENT LIST                   \n";
    cout << "=================================================\n";
    if (items.empty()) {
        cout << "  No instruments available.\n";
    } else {
        cout << left << setw(5) << "No." << setw(15) << "Name" 
             << setw(10) << "Weight" << setw(10) << "Value" << endl;
        cout << "-------------------------------------------------\n";
        for (int i = 0; i < items.size(); i++) {
            cout << left << setw(5) << i+1 
                 << setw(15) << items[i].name
                 << setw(10) << items[i].weight
                 << setw(10) << items[i].value << endl;
        }
    }
    cout << "=================================================\n";
}

// Save to file
void saveData(const vector<Instrument>& items) {
    ofstream file("data.txt");
    for (auto &i : items)
        file << i.name << " " << i.weight << " " << i.value << endl;
    file.close();
    cout << "\n[+] Data successfully saved to 'data.txt'!\n";
}

// Load from file
void loadData(vector<Instrument>& items) {
    ifstream file("data.txt");
    if (!file) {
        cout << "\n[-] No saved data found!\n";
        return;
    }
    Instrument temp;
    items.clear();
    while (file >> temp.name >> temp.weight >> temp.value) {
        items.push_back(temp);
    }
    file.close();
    cout << "\n[+] Data successfully loaded from 'data.txt'!\n";
}

// 0/1 knapsack
void knapsack(const vector<Instrument>& items, int maxW) {
    int n = items.size();

    if (n == 0) {
        cout << "\n[-] No instruments available to optimize!\n";
        return;
    }

    if (maxW <= 0) {
        cout << "\n[-] Invalid capacity! Weight must be > 0.\n";
        return;
    }

    vector<vector<int>> dp(n+1, vector<int>(maxW+1, 0));

    // Fill DP
    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= maxW; w++) {
            if (items[i-1].weight <= w) {
                dp[i][w] = max(
                    items[i-1].value + dp[i-1][w-items[i-1].weight],
                    dp[i-1][w]
                );
            } else {
                dp[i][w] = dp[i-1][w];
            }
        }
    }

    cout << "\n=================================================\n";
    cout << "              OPTIMIZATION RESULTS               \n";
    cout << "=================================================\n";
    cout << "  Maximum Total Value: " << dp[n][maxW] << endl;

    // Backtracking
    int w = maxW;
    int totalW = 0;

    cout << "\n  Selected Instruments:\n";
    cout << "  ---------------------\n";
    bool any_selected = false;
    for (int i = n; i > 0; i--) {
        if (dp[i][w] != dp[i-1][w]) {
            cout << "   [*] " << items[i-1].name << " (Weight: " << items[i-1].weight << ", Value: " << items[i-1].value << ")\n";
            totalW += items[i-1].weight;
            w -= items[i-1].weight;
            any_selected = true;
        }
    }
    
    if (!any_selected) {
        cout << "   (None)\n";
    }

    // Efficiency metrics
    cout << "\n  Efficiency Metrics:\n";
    cout << "  -------------------\n";
    cout << "  Total Weight : " << totalW << " / " << maxW << endl;
    cout << "  Remaining Cap: " << (maxW - totalW) << endl;
    cout << "  Efficiency (Value/Weight): "
         << fixed << setprecision(2)
         << (double)dp[n][maxW] / max(totalW,1) << endl;
    cout << "=================================================\n";
}

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

int main() {
    vector<Instrument> items;
    string choice_str;
    int choice;
    int maxW = 0;

    clearScreen();
    cout << "=================================================\n";
    cout << "       SATELLITE INSTRUMENT OPTIMIZER            \n";
    cout << "=================================================\n\n";
    
    while (maxW <= 0) {
        cout << "Enter Satellite Maximum Weight capacity: ";
        cin >> maxW;
    }

    while (true) {
        cout << "\n=================================================\n";
        cout << "                 MAIN MENU                       \n";
        cout << "=================================================\n";
        cout << "  [1] Add Instrument\n";
        cout << "  [2] Display Instruments\n";
        cout << "  [3] Run Optimization\n";
        cout << "  [4] Save Data\n";
        cout << "  [5] Load Data\n";
        cout << "  [6] Update Capacity\n";
        cout << "  [7] Exit\n";
        cout << "-------------------------------------------------\n";
        cout << "  Current Capacity -> Max Weight: " << maxW << "\n";
        cout << "=================================================\n";
        cout << "Enter your choice: ";
        cin >> choice_str;

        try {
            choice = stoi(choice_str);
        } catch (...) {
            cout << "\n[-] Invalid input. Please enter a number between 1 and 7.\n";
            continue;
        }

        if (choice == 1) {
            Instrument i;
            cout << "\n--- Add New Instrument ---\n";
            cout << "Name: "; cin >> i.name;
            cout << "Weight: "; cin >> i.weight;
            cout << "Value: "; cin >> i.value;
            items.push_back(i);
            cout << "[+] " << i.name << " added successfully!\n";
            saveData(items);
        }
        else if (choice == 2) {
            display(items);
        }
        else if (choice == 3) {
            bool running_optimization = true;
            while (running_optimization) {
                knapsack(items, maxW);

                // What-if analysis
                char again;
                cout << "\nTry optimization with a different capacity? (y/n): ";
                cin >> again;
                if (again == 'y' || again == 'Y') {
                    cout << "Enter new test Max Weight: ";
                    cin >> maxW;
                } else {
                    running_optimization = false;
                }
            }
        }
        else if (choice == 4) {
            saveData(items);
        }
        else if (choice == 5) {
            loadData(items);
        }
        else if (choice == 6) {
            cout << "\n--- Update Capacity ---\n";
            cout << "Enter new Satellite Maximum Weight capacity: ";
            cin >> maxW;
            cout << "[+] Capacity updated!\n";
        }
        else if (choice == 7) {
            saveData(items);
            cout << "\nExiting... Goodbye!\n";
            break;
        }
        else {
            cout << "\n[-] Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
