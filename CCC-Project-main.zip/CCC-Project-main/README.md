# 🚀 Satellite Instrument Optimizer

A C++ console-based application that helps optimize the selection of satellite instruments using the **0/1 Knapsack Algorithm**. The system allows users to manage instruments, perform optimization, and analyze efficiency based on weight constraints.

---

## 📌 Features

- 📥 Add new instruments (name, weight, value)
- 📋 Display all instruments in a structured format
- ⚙️ Optimize instrument selection using **Dynamic Programming (0/1 Knapsack)**
- 💾 Save instrument data to file (`data.txt`)
- 📂 Load instrument data from file
- 🔄 Update satellite weight capacity dynamically
- 📊 Efficiency metrics (Value/Weight ratio, remaining capacity)
- 🧪 What-if analysis with different capacities

---

## 🧠 Algorithm Used

### 0/1 Knapsack Algorithm
- Uses **Dynamic Programming (DP)** approach
- Maximizes total value without exceeding weight capacity
- Time Complexity: **O(n × W)**
- Space Complexity: **O(n × W)**

---

## 🛠️ Tech Stack

- Language: **C++**
- Concepts Used:
  - Structures (`struct`)
  - Vectors (`std::vector`)
  - File Handling (`fstream`)
  - Dynamic Programming
  - Input validation

---

## 📂 Project Structure

```
📁 Satellite-Instrument-Optimizer
 ├── 1.cpp        # Main source code
 ├── data.txt     # Stored instrument data (generated at runtime)
 ├── README.md    # Project documentation
```

---

## ▶️ How to Run

### 🔹 Compile
```bash
g++ 1.cpp -o optimizer
```

### 🔹 Run
```bash
./optimizer
```

*(On Windows: `optimizer.exe`)*

---

## 🧾 Sample Menu

```
[1] Add Instrument
[2] Display Instruments
[3] Run Optimization
[4] Save Data
[5] Load Data
[6] Update Capacity
[7] Exit
```

---

## 📊 Example Output

```
Maximum Total Value: 220

Selected Instruments:
[*] Camera (Weight: 10, Value: 60)
[*] Sensor (Weight: 20, Value: 100)

Efficiency Metrics:
Total Weight : 30 / 50
Remaining Cap: 20
Efficiency (Value/Weight): 7.33
```

---

## 💡 Use Cases

- Satellite payload optimization
- Resource allocation problems
- Budget vs value decision-making
- Academic demonstration of Knapsack problem

---

## ⚠️ Limitations

- Console-based UI (no GUI)
- Fixed file format (`data.txt`)
- No strict validation for negative values

---

## 🔮 Future Improvements

- Add GUI (using Qt / Web interface)
- Support CSV/JSON data formats
- Visualization of DP table
- Multi-constraint optimization (e.g., power, volume)


